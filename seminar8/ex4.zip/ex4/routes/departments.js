const express = require("express");
const { departments } = require("../db");
const router = express.Router();

router.get("/departments", (req, res) => {
    res.json(departments);
});

module.exports = router;
