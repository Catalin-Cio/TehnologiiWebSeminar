"use strict";

const express = require("express");
const departmentsRouter = require("./routes/departments");
const statusRouter = require("./routes/status");
require("dotenv").config();

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use((req, res, next) => {
    console.log(`\n--- HTTP Request ---`);
    console.log(`Method: ${req.method}`);
    console.log(`URL: ${req.url}`);
    if (Object.keys(req.query).length > 0) {
        console.log(`Query:`, req.query);
    }
    if (Object.keys(req.body).length > 0) {
        console.log(`Body:`, req.body);
    }
    console.log(`-------------------\n`);
    next();
});

app.use("/api", departmentsRouter);
app.use("/status", statusRouter);

app.set("port", process.env.PORT || 7000);

app.listen(app.get("port"), () => {
    console.log(`Server started on http://localhost:${app.get("port")}`);
});
