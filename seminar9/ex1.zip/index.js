"use strict";

const express = require("express");
const sequelize = require("./config/sequelize");
const Employee = require("./models/Employee");

const app = express();

app.use(express.json());

app.set("port", process.env.PORT || 7000);

app.listen(app.get("port"), async () => {
  console.log(`Server started on http://localhost:${app.get("port")}`);

  try {
    await sequelize.authenticate();
    console.log("Connection has been established successfully.");

    await sequelize.sync({ force: true });
    console.log("All models were synchronized successfully.");
  } catch (error) {
    console.error("Unable to connect to the database:", error);
  }
});
