const { DataTypes } = require("sequelize");
const sequelize = require("./index");

const Employee = sequelize.define("Employee", {
    name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            len: {
                args: [3, 10],       // validator cerut
                msg: "Name must be between 3 and 10 characters"
            }
        }
    },
    position: {
        type: DataTypes.STRING,
        allowNull: false
    },
    salary: {
        type: DataTypes.INTEGER,
        defaultValue: 0,           // valoare default
        validate: {
            min: {
                args: [0],         // validare minim 0
                msg: "Salary cannot be negative"
            }
        }
    }
});

module.exports = Employee;
