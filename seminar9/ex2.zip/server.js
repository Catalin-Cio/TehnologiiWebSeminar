const express = require("express");
const app = express();
const sequelize = require("./models");
const employeeRoutes = require("./routes/employeeRoutes");

app.use(express.json());
app.use("/employees", employeeRoutes);

sequelize.sync().then(() => {
    console.log("Database synced");

    app.listen(3000, () => {
        console.log("Server running at http://localhost:3000");
    });
});
